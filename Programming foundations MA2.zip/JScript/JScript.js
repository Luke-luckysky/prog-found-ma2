var myVar;
console.log("myVar");

var stringfour = "4";
var numberfour = 4;

if (stringfour !== numberfour) {
    console.log ( "equal" );
} else {
    console.log ( "not equal" );
}


var numbers = [2, 54, 67, 85];
var booleans = [true, false, false, true];
var mixedValues = ["blue", 54, false, 85, null];
var numberofbooleans = booleans.length;

console.log(numberofbooleans);

var yourArray = [];
console.log(yourArray.length);

yourArray.push(19);
console.log(yourArray.length);
console.log(yourArray);

var colors = ["blue", "red", "gold", "green"]
console.log(colors);

colors.push ("purple");
console.log(colors);
console.log(colors.length);


var post = [
    {
        imageUrl: "link",
        likeCounter: 3245,
        likedByUser: true
    },
    {
        imageUrl: "anotherlink",
        likeCounter: 343532,
        likedByUser: false
    },
    {
        imageUrl: "anotherdog",
        likeCounter: 34934,
        likedByUser: true
    },
    {
        imageUrl: "anotherpandad",
        likeCounter: 9245924,
        likedByUser: false
    },
];

for(var i = 0; i < post.length; i++) {
    console.log(post[i].imageUrl);
}
for(var i = 0; i < post.length; i++) {
    console.log(post[i].likeCounter);
}
for(var i = 0; i < post.length; i++) {
    console.log(post[i].likedByUser);
}


function loghardCode() {
    console.log("Hello Barfenator, why do you barf all the time?");
};
loghardCode();

function logSentance(theSentance, arg2, arg3) {
    console.log(theSentance, arg2, arg3);
};
logSentance("Hello Barfenator, why do you barf all the time?", " Because I want to", 20);

function logBug(theBug) {
    console.log(theBug);
};
logBug(true);
logBug(false);
logBug("I AM NOT A BUG");
logBug("YES YOU ARE!");

function likeCounter(likeCounter) {
    console.log(likeCounter + " likes");
};
likeCounter(89);
likeCounter(3457586568564646876785685685858685685856868);
likeCounter(8574);

function returnlikeCounter(returnCounter) {
    return returnCounter + " likes";
};
console.log(returnlikeCounter(34325));

var count = returnlikeCounter(234325);
console.log(count);


function addTwoNumbers(num1, num2) {
    return num1 + num2 ;
};
console.log(addTwoNumbers(32, 32));


var dog = {
    name: "tripod",
    breed: "labrador",
    numberOfLegs: 3
};
console.log(dog.breed);


var posts = [
    {
        imageUrl: "https://path/to/bee-picture",
        likeCounter: 80,
        likedByUser: true
    },
    {
        imageUrl: "https://path/to/tree-picture",
        likeCounter: 120,
        likedByUser: false
    },
    {
        imageUrl: "https://path/to/bat-picture",
        likeCounter: 142,
        likedByUser: true
    }
];
console.log(posts.length);

for(var i = 0; i < posts.length; i++) {

    console.log(posts[i].likeCounter);
};

for(var i = 0; i < posts.length; i++) {

    console.log(posts[i].imageUrl);
    console.log(posts[i].likeCounter);
    console.log(posts[i].likedByUser);
};

function logWord1() {
    console.log("one");
}

logWord1();


function logWord2(theWord) {
    console.log("one");
}

logWord2();

function logWord(theWord) {
    console.log(theWord);
}

logWord(true);



function realWord(theNumbers) {
    
    console.log("The argument is " + theNumbers + " Dollars");
}

realWord(45);
realWord(54);
realWord(64);

function printLikeCounter(likeCounter1) {
    console.log(likeCounter1 + " loves");
}

printLikeCounter(80);
printLikeCounter(120);
printLikeCounter(142);


function createLikeCounter1(likeCounter2) {
    return likeCounter2 + " likes";
}

var counter2 = createLikeCounter1(80);
console.log(counter2);

function createLikeCounter(likeCounter) {
    return "<div><b>" + likeCounter + "</b> likes</div>" 
}

var counter = createLikeCounter(80);
console.log(counter);

function addingNumbers(number1, number2) {
    var sum = number1 + number2;
    console.log(sum);
}

addingNumbers(43, 465);

function nameCalling(firstname,lastname) {
    
    var fullName = "You are called" + " " + firstname + " " + lastname;
    if (firstname !== "jerry") {
        return "MONSTER!!!";
    } else {
        return fullName;
    }
}

var nameCalled = nameCalling("jerry", "bean");
console.log(nameCalled);
var nameCalled1 = nameCalling("Jessy", "Jones");
console.log(nameCalled1);
var nameCalled2 = nameCalling("jerry", "manstran");
console.log(nameCalled2);
var nameCalled3 = nameCalling("Afrodite", "merryanna");
console.log(nameCalled3);
