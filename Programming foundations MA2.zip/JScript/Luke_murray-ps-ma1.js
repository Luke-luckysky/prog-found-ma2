
//Question 1
var fistVar;

//Question2
var name = "Luke";

//Question 3
var number = 1;

//Question 4
var division = 20 / 5;

//Question 5
var orderHasShipped = true;

//Question 6
console.log(typeof "frog");

//Question 7
if (orderHasShipped === true) {
    console.log("true")
} else {
    console.log("lights is of")
};

//Question 8
for (count = 1; count <= 9; count++) {
    console.log(count)
};


var 